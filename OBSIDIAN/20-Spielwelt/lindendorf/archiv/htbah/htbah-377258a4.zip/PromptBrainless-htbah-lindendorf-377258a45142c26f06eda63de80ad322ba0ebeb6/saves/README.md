# Spielstände

Eine Datei pro Name. Schema siehe `src/save/named-save.ts`.

Beispiel `saves/anna.json`:

```json
{
  "version": 2,
  "name": "Anna",
  "savedAt": "2026-09-21T16:00:00.000Z",
  "state": {}
}
```

Der Browser-Slot unter demselben Namen hat Vorrang, solange man im gleichen Browser spielt.
