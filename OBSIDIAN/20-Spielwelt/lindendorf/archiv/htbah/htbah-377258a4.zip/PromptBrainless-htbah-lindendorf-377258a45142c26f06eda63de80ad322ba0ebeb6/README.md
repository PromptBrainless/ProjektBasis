# How to be a Hero — Lindendorf

Dunkles Textabenteuer über ein armes Tal, einen alten Steinbruch und Entscheidungen, die länger bleiben als ihre Helden.

Drei Attribute, W10, Gunst und Last, sichtbare Konsequenzen.

**Live:** [spielversion2.grok.me](https://spielversion2.grok.me/)

## Was in diesem Repo liegt

Der Quelltext der laufenden Grok-Build-App liegt nicht als offenes TypeScript vor — ausgeliefert wird ein gebündeltes Frontend. Hier liegt die **ordentliche Arbeitsbasis** für den Neubau von Weltwerkzeug, Darstellung und Kernregeln.

```
docs/
  weltwerkzeug/
    00-ANWEISUNG.md          harte Bau-Anweisung (vor System-Defaults)
    01-OPTIMIERUNG-KERN.md   Prosa, Graph, Probe, Attribute, /art, Flags
  renderer-contracts/
    00-VOLLTEXT.md           ursprünglicher Renderer-/Adapter-Vertrag 1:1
    00-INDEX.md              Navigation dazu
  SPEICHER.md                namensbasiertes Speichern
src/save/named-save.ts       Drop-in für Speichern/Laden per Name
saves/                       Projekt-Archiv der Spielstände
```

## Speichern

Ein Name = ein Slot. Speichern legt den Stand unter dem Heldennamen ab. Wer denselben Namen wieder eingibt, lädt denselben Stand.

Verdrahtet in [SpielVersion1.0](https://github.com/PromptBrainless/SpielVersion1.0). Modul und Vertrag hier: `docs/SPEICHER.md`.

## Spielkern (Live-Stand)

| Stück | Regel |
| --- | --- |
| Probe | `W10 + Attribut + Gunst/Last/Lage ≥ Schwelle` |
| Schwellen | leicht 8 · mittel 12 · schwer 15 |
| Attribute | Stärke, Geschick, Charisma |
| LP | 10, Tod bei 0 |
| Hubs | Dorf, Mühle, Brunnen, Gasse, Lager |

Details und was daran schief verdrahtet ist: `docs/weltwerkzeug/01-OPTIMIERUNG-KERN.md`.

## Weltwerkzeug

Sollzustand: vier getrennte Werkzeuge — **Karte**, **Held**, **Stimme**, **Prüfen**.

Kanon bleibt unangetastet. Auflagen sind explizit und umkehrbar. Der Held sieht nie rohe Flags.

Einstieg für einen Agenten oder Entwickler: zuerst `docs/weltwerkzeug/00-ANWEISUNG.md`.

## Namensraum

| Name | Bedeutung |
| --- | --- |
| `htbah-lindendorf` | dieses Repository |
| Lindendorf | das Tal / das Abenteuer |
| How to be a Hero | Regelgrundlage (Hausregel: 3 Attribute, W10) |
| spielversion2.grok.me | aktuelle Ausspielung |

## Hinweis zum App-Quelltext

Wer den laufenden React-Bundle-Stand braucht: die öffentlichen Assets hängen unter derselben Domain (`/assets/…`, `/art/…`). Das ist kein Ersatz für den Grok-Build-Projektordner. Sobald der Quellordner exportiert ist, gehört er in `src/` in diesem Repo, nicht als Minify-Dump.
