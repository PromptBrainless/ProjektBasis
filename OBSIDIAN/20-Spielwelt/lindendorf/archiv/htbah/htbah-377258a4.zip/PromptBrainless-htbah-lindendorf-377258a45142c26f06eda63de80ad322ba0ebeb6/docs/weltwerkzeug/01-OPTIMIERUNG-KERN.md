# Optimierung der Kernbereiche

Quelle: Live-Code von https://spielversion2.grok.me/
Spielbarer Stand mit Speicher: [SpielVersion1.0](https://github.com/PromptBrainless/SpielVersion1.0)
Stand: 21.09.2026.

Rangordnung bleibt `00-ANWEISUNG.md`. Hier steht nur, was am **Spielkern** scharf gestellt wird — nicht am Kanon.

## Live-Formel

```
W10 = 1 + floor(random * 10)
effektiv = Attribut + Gunst/Last + Lage + Sonder
Erfolg  = (W10 + effektiv) >= Schwierigkeit
leicht 8 · mittel 12 · schwer 15
LP-Max 10
```

Sonder: Nebel −2. Erschöpfung zählt **einmal** (Last `mod.all −1`), nicht noch einmal als Lage.

## 1. Szenenprosa
Zwei Stimmen: Lagen in Ich-Form, Tal in Du-Form. Tal-Stimme behalten. Eine Metapher pro Hub. Keine Flag-Namen im Fließtext.

## 2. Entscheidungsgraph
Hubs: Dorfplatz, Mühle, Brunnen, Gasse, Lager.
Lösungsfelder: `loesungswegMuehle`, `loesungswegBrunnen`, `loesungswegGasse`, `loesungsweg`.
IDs qualifizieren (`muehle.hub:schleich`), alte IDs als Alias. Keine Enden streichen.

## 3. Probenformel
UI muss die echte Summe zeigen. Attributnamen vereinheitlichen (ST/GE/CH). Choice-Label und Schwelle identisch. Erschöpfung nur einmal zählen. Kein W100.

## 4. Attribute, Gunst, Last, LP
Grundwert bleibt. HUD zeigt Herkunft der Mods. Lage getrennt von Gunst/Last. Schaden ≥3 setzt Wunde. Heilen auf LP ≥8 nimmt Wunde (Flag und Effekt).

## 5. /art
41 Dateien. Zwei Bildsprachen. Fehlende Porträts: Fenn, Grete, Vahl, Lene, Rennik. Tote Keys in Prüfen markieren. Neue Bilder nur als Auflage.

## 6. Flags
Nicht umbenennen. `sennaBesuche` bleibt, Alias im Mapper. Player sieht Wissens-Labels, GM sieht Rohflags.

## 7. Speichern
Ein Heldenname = ein Slot. Gleicher Name (Trim, Kleinbuchstaben de-DE) lädt denselben Stand.
Browser: `lindendorf-saves-v2`. Projektarchiv: `saves/<name-key>.json`.
Kein neues Save-Schema am Held. Welt-Auflagen (`lindendorf.welt.v2`) bleiben vom Partie-Stand getrennt.
Vertrag: `docs/SPEICHER.md`.
