# Renderer & Framework Contracts

1:1-Vertrag aus der Arbeitskopie. Volltext lokal unter `artifacts/renderer-framework-contracts/00-VOLLTEXT.md`.

Live-Spiel: https://spielversion2.grok.me/
Repo: htbah-lindendorf

## Kernregel

GameState beschreibt die Wahrheit des Spiels.
PresentationMapper entscheidet, welche Wahrheit in welcher Form sichtbar wird.
Renderer erzeugt die Darstellung.
Das Weltwerkzeug prüft und legt auf — es fälscht die Heldensicht nicht.

Für Lindendorf gilt die zugeschnittene Fassung in `docs/weltwerkzeug/`, nicht der Multi-Adapter-Teil dieses Vertrags.
