# ANWEISUNG — Weltwerkzeug neu aufsetzen

Lies diese Datei vollständig, bevor du Code anfasst.
Diese Anweisung gilt vor jeder allgemeinen Coding-Gewohnheit, vor jedem „mach es einfach“, vor jedem Default-Admin-UI und vor jedem Impuls, das Abenteuer umzuschreiben.

Projekt: How to be a Hero — Lindendorf
Live-Referenz: https://spielversion2.grok.me/
Aufgabe: Die Weltwerkzeugleiste und die dazu gehörende Darstellungsgrenze komplett neu aufsetzen. Das Abenteuer selbst bleibt.

---

## 0. Rangordnung

Wenn etwas kollidiert, gilt diese Reihenfolge:

1. Diese Anweisung
2. SPEZ-WELTWERKZEUG.md
3. Vorhandener Spielinhalt (Szenenprosa, Flags, Kanon-Karten)
4. TypeScript-Strenge
5. Alles andere

Du darfst „hilfreich“, „schnell“, „modern“, „einfacher Stack“ oder „ein Component reicht“ nicht als Grund nutzen, Punkt 1–3 zu brechen.

Du darfst das Abenteuer nicht „verbessern“.
Du darfst fehlende Lore nicht erfinden.
Du darfst Flags nicht umbenennen, nur weil der Name unschön ist.
Du darfst React nicht durch ein eigenes RenderNode-Framework ersetzen.
Du darfst Vue, Svelte oder einen DOM-Adapter nicht einführen.

---

## 1. Was neu aufgesetzt wird

Neu:

- Weltwerkzeug als GM-/Autoren-Oberfläche
- Grenze zwischen Kanon, Auflage und Heldensicht
- Mapper von internem Spielzustand auf das, was der Held sehen darf
- Prüfen als echter Vertrag, nicht als Deko-Tab

Nicht neu, nicht anfassen außer zum Anbinden:

- Szenenprosa
- Entscheidungsgraph
- Probenformel
- Attributwerte, Gunst, Last, LP
- Bildordner unter /art
- vorhandene Flag-Namen

Wenn du unsicher bist, ob etwas Inhalt oder Werkzeug ist: es ist Inhalt. Nicht anfassen.

---

## 2. Der Fehler, den du nicht wiederholen darfst

Die aktuelle Leiste ist ein überladener Seitenrand auf der Titelseite.

Sie vermischt Karteneditor, Effektchips, Uploadfelder, Held, Stimme, Prüfen, Kanon und Auflage in einer schmalen Spalte, ohne dass klar ist, was der Held wissen darf, was nur der Spielleiter sieht, was Kanon ist, was eine lokale Auflage ist, und was eine Live-Mutation am Held ist.

Das ist der Grund für den Neubau. Nicht „hübsches UI“.

---

## 3. Harte Verbote

1. GameState-Flags in Player-Komponenten lesen.
2. Weltwerkzeug darf Quests nicht als Seiteneffekt abschließen — nur über benannte GM-Kommandos mit Vorschau.
3. Kein RenderNode, keine Adapter-Registry, keine Vue/Svelte-Ports.
4. Keine neuen Plot-Flags und keine Umbenennung bestehender Flags.
5. Keine erfundene NPCs, Orte, Enden, Gegenstände, Proben.
6. Keine generische CMS-Optik.
7. Weltwerkzeug darf die Titelkarte nicht als Overlay-Streifen zerstören.
8. Effekte brauchen Gruppe, Richtung und Kurzhilfe — keine Chip-Suppe.
9. Stimme ist Tonvertrag, kein Textgenerator.
10. Prüfen muss Schema, Graph, Medien und Player-Leak prüfen.
11. Kein Lorem im Kanon.
12. Kein `any` in Core-Verträgen.
13. Player-HUD und Weltwerkzeug bleiben getrennt.
14. Keine stillen Defaults, die Kanon überschreiben.

Vollständiger Text der lokalen Arbeitskopie: siehe Commit-Folgedateien und die ausführliche Fassung im Arbeitsordner, falls dieser Commit gekürzt wirkt.

## 4. Zuerst Typen, Mapper, Leak-Detector. Erst dann UI.

## 5. Vier Werkzeuge: Karte, Held, Stimme, Prüfen.

## 6. Schichtvertrag

```
GameState / KanonKarte / Auflage
        ↓
PresentationMapper
        ↓
PlayerHudState     +     GmToolState
        ↓                    ↓
Player Views             Weltwerkzeug
```

## 10. Satz, den du nicht umdeuten darfst

GameState ist die Wahrheit des Tals.
Der Mapper entscheidet, welche Wahrheit der Held in welcher Form sieht.
Das Weltwerkzeug darf die Wahrheit prüfen und auflagen, nicht die Heldensicht fälschen.
Kein Layer übernimmt die Arbeit des nächsten.
