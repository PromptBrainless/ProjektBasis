/**
 * Namensbasiertes Speichern für How to be a Hero — Lindendorf (Spielversion 2).
 * Ein Name = ein Slot. Gleicher Name lädt denselben Stand.
 */

export const SLOTS_KEY = "lindendorf-saves-v2";
export const LAST_NAME_KEY = "lindendorf-save-last-name";

export type NamedSave<T = unknown> = {
  version: 2;
  name: string;
  savedAt: string;
  state: T;
};

export type NamedSaveInfo = {
  name: string;
  nameKey: string;
  savedAt: string;
};

export function normalizeName(name: string): string {
  return name.trim().replace(/\s+/g, " ");
}

export function nameKey(name: string): string {
  return normalizeName(name).toLocaleLowerCase("de-DE");
}

function readAll<T>(): Record<string, NamedSave<T>> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(SLOTS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, NamedSave<T>>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function writeAll<T>(slots: Record<string, NamedSave<T>>): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(SLOTS_KEY, JSON.stringify(slots));
    return true;
  } catch {
    return false;
  }
}

export function saveNamed<T>(name: string, state: T): boolean {
  const clean = normalizeName(name) || "Namenlos";
  const key = nameKey(clean);
  const payload: NamedSave<T> = {
    version: 2,
    name: clean,
    savedAt: new Date().toISOString(),
    state,
  };
  const slots = readAll<T>();
  slots[key] = payload;
  const ok = writeAll(slots);
  if (ok && typeof window !== "undefined") {
    window.localStorage.setItem(LAST_NAME_KEY, clean);
  }
  return ok;
}

export function loadNamed<T>(name: string): NamedSave<T> | null {
  const key = nameKey(name);
  if (!key) return null;
  const slot = readAll<T>()[key] ?? null;
  if (slot && typeof window !== "undefined") {
    window.localStorage.setItem(LAST_NAME_KEY, slot.name);
  }
  return slot;
}

export function loadLastNamed<T>(): NamedSave<T> | null {
  if (typeof window === "undefined") return null;
  const last = window.localStorage.getItem(LAST_NAME_KEY);
  if (last) return loadNamed<T>(last);
  const all = listNamed();
  return all[0] ? loadNamed<T>(all[0].name) : null;
}

export function listNamed(): NamedSaveInfo[] {
  return Object.entries(readAll())
    .filter(([, slot]) => slot && typeof slot.name === "string")
    .map(([key, slot]) => ({
      name: slot.name,
      nameKey: key,
      savedAt: slot.savedAt,
    }))
    .sort((a, b) => b.savedAt.localeCompare(a.savedAt));
}

export function clearNamed(name: string): void {
  const slots = readAll();
  delete slots[nameKey(name)];
  writeAll(slots);
}

export function toProjectFile<T>(slot: NamedSave<T>): string {
  return `${JSON.stringify(slot, null, 2)}\n`;
}

export function projectPath(name: string): string {
  const key = nameKey(name).replace(/[^a-z0-9_-]+/gi, "-") || "namenlos";
  return `saves/${key}.json`;
}
